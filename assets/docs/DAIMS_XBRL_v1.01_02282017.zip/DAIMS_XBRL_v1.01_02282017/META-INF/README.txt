README.txt for DATA Act DAIMS taxonomy 2017-02-28

This README lives in the META-INF directory of the DAIMS XBRL Taxonomy Package.  Taxonomy files are in the parent of this directory.  The metadata files of this directory are the XBRL standard taxonomyPackage.xml file and Oasis standard catalog.xml file.  The taxonomy package file provides the version, entry point for the taxonomy, the versioning report, and in later versions will indicate superseded prior version taxonomy package zip files (that this package zip replaces).

(Separately available are diagram files of the model underlying the taxonomy, an Excel XBRL Taxonomy Model workbook file, and XBRL Sample Instance files.)

Files included in the parent directory of this XBRL Taxonomy Package:

1. daims_core_v1.01_2017-02-28.xsd

This is the "entry point" for DTS discovery, which references the linkbases and imports the type definition file.

This file includes the DATA Act project type definitions and xbrl concept elements.  The type definitions include element type restrictions of facets such as lengths, patterns, and enumerations.

2. daims_core_v1.01_2017-02-28_pre.xml

This is the presentation linkbase for the schema.  It covers packages A - F, each package is a separate link role.

3. daims_core_v1.01_2017-02-28_lab.xml

This is the label linkbase which provides standard, terse, documentation, instruction and rules labels for the concept elements in the schema.

4. daims_core_v1.01_2017-02-28_lab_enum.xml

This is the label linkbase which provides enumerations labels for the elements with restriction enumerations in the schema.  Also included are generic standard labels for non-concept elements in the schema (typed dimension member elements that aren't concept items).  This linkbase is separate from the _lab.xml label linkbase because it provides XBRL generic labels for each schema enumeration restrictions and non-concept elements.

5. daims_core_v1.01_2017-02-28_def.xml

This is the definition linkbase for the schema which defines dimensions and dimensional validation.  Data act dimensions are primarily code-enumerative typed dimensions, the code values of agency inputs have been preserved for compatibility with XBRL OIM CSV notation (instead of converting code values into XBRL Concept QNames).

6. daims_core_v1.01_2017-02-28_ref.xml

This is the reference linkbase for the taxonomy concepts references such as the RSS-IDD reference number.

6. daims_core_v1.01_2017-02-28_ref_metadata.xml

This is the reference linkbase for the taxonomy concepts metadata such as element level Required, Required Context and Rule codes.


XBRL Taxonomy Package Structure

The XBRL Taxonomy Package (which contains this README.txt file) is a zip file according to the XBRL specification at http://specifications.xbrl.org/work-product-index-taxonomy-packages-taxonomy-packages-1.0.html.

The taxonomy is specified by separate link roles (presentation groups) corresponding to DAIMS packages A, B, C, D1, D2, E and F.  Each XBRL link role uses the corresponding presentation group name:

Package	Link Roles for Submission Modeling
Pkg A	0100 - Appropriations Account Submission Package
Pkg B	0200 - Object Class and Program Activity Submission Package
Pkg C	0300 - Award Financial Submission Package
Pkg D1	0400 - Award Procurement Extract Package
Pkg D2	0500 - Award Financial Assistance Extract Package
Pkg E	0600 - Additional Awardee Attributes Extract Package
Pkg F	0700 - Sub Award Attributes Extract Package

Package Link Roles for Consumption Use
Pkg A2	0102 - Appropriations Account Package
Pkg A3	0103 - Financial Account Package
Pkg D3	0503 - Award Package


XBRL Taxonomy Background

The taxonomy is developed using current best practice for XBRL, and stored in the XML syntax used at present by XBRL.  It can also be represented by an XBRL database (using the XBRL abstract model). 

The XBRL model for DAIMS is a standard authority-provided taxonomy, it does not anticipate per-filing extensions such as used by SEC and IFRS financial reporting. 

XBRL is processed using an XBRL processor (not an XML parser).  Open source and commercial products are available to process XBRL and load databases of XBRL-sourced data.

The schema and linkbase files follow the XBRL Taxonomy Architecture Guidance (http://www.xbrl.org/guidance/taxonomy-architecture/XBRLTaxonomyGuidanceDocument-v1.2.pdf), which results in well-modeled semantics that are interoperable between a large number of tools and agencies. XBRL serializes its model as an XML schema and linkbases, but is evolving to support multiple serialization and database standards (such as JSON, CSV, and SQL).  In particular, these metadata of the DAIMS project are modelled by XBRL as follows:

DAIMS	XBRL Metadata
Package	Link role
Element	Concept
Element order	Presentation linkbase order
" semantic label	Concept standard label, name (camel-cased tokenized name)
" Standard definition	Concept documentation label
" Instructions	Concept submission instruction reference part
" Abstract	Schema abstract attribute (true/false)
" Value required	Concept element use reference part
" Validation rules	Concept validation rules reference part(s)
" Required context	Concept business reporting context reference part
" Enumeration	Schema-level enumeration restriction
" Enumeration labels	Generic standard labels on enumeration restriction elements
Presentation order	Presentation linkbase
Record structure	XBRL context containers (typed dimensions)
Version report	XBRL version report
Zip file of taxonomy	XBRL taxonomy package
