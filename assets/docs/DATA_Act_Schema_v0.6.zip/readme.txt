VERSION HISTORY
- Version 0.1 � Public Release: Initial release of the draft DATA Act Schema financial taxonomy 
- Version 0.2 � Public Release: Baseline release of DATA Act Schema financial taxonomy. 
  o Updated Treasury Account Symbol (TAS) to component TAS. 
  o Updated to include an agency complex type consisting of an agency name and agency identifier and formalized folder structure for supporting future module releases. 
  o Updated address complex type to support multiple street address lines
  o Changed awardNumber and parentAwardNumber in USSGL-FIN to standardized term awardID and parentAwardID- Github defines these as awardID and parentAwardID which is how it is also declared in the Financial Assistance taxonomy
- Version 0.3 
  o Updated to include county as a standard element under the standard address complex type
  o Updated to support variable number of highly compensated officers by removing �top5� from the element names (top5HighlyCompensatedOfficer -> highlyCompensatedOfficer)
  o Updated to include Financial Assistance and Procurement specific elements 
  o Renamed element subTierAgency to awardingSubTierAgency to distinguish from fundingSubTierAgency
  o Renamed element performancePlaceAddress to primaryPlaceOfPerformance 
  o Renamed elements from performancePeriod to periodOfPerformance
  o Revised DATA Act element parentAwardID from integerItemType to stringItemType to be consistent with awardID.
  o Revised the address complex type to accommodate variable number of streetAddressLine by adding a complex type of streetAddress
  o Revised awardeeParentDUNS to ultimateParentUniqueIdentifier and awardeeParentLegalBusinessName to ultimateParentLegalBusinessName
  o Removed examples and length requirements (not defined by the schema) and included # of occurrences.
- Version 0.4
  o Changed �Treasury Accounting Symbol� to �Treasury Account Symbol� within this document.
  o Renamed the complex type treasuryAccountingSymbol to treasuryAccountSymbol.
  o Removed the specialLegislativeIndicator element.
  o Renamed the element fundingActionObligation to federalFundingAmount
  o Renamed the element currentTotalFundingObligationAmountOnAward to totalFundingAmount
  o Renamed the element catalogOfFederalDomesticAssistanceProgramTitle to catalogOfFederalDomesticAssistanceTitle within the complex type catalogOfFederalDomesticAssistanceProgram
  o Renamed the element catalogOfFederalDomesticAssistanceProgramNumber to catalogOfFederalDomesticAssistanceNumber within the complex type catalogOfFederalDomesticAssistanceProgram
- Version 0.5: � Public Release: Initial release of the award level DATA Act Schema taxonomy
  o Updated definitions of awardeeLegalBusinessName, awardeeUniqueIdentifier, and awardeeAddress.
  o Added new element highlyCompensatedOfficersMiddleInitial.
  o Updated definitions of countryName, countryCode, and congressionalDistrict.
  o Update the Max Occurrence of streetAddressLine.
- Version 0.6: -- Public Release:  
