README.txt for DataAct DAIMS taxonomy 2016-04-29

This README lives in the META-INF directory of the DAIMS XBRL Taxonomy Package.  Taxonomy files are in the parent of this directory.  The metadata files of this directory are the XBRL standard taxonomyPackage.xml file and Oasis standard catalog.xml file.  The taxonomy package file provides the version, entry point for the taxonomy, the versioning report, and in later versions will indicate superseded prior version taxonomy package zip files (that this package zip replaces).

(Separately available are diagram files of the model underlying the taxonomy, an Excel XBRL Taxonomy Model workbook file, and XBRL Sample Instance files.)

Files included in the parent directory of this XBRL Taxonomy Package:

1. daims-20160429.xsd

This is the "entry point" for DTS discovery, which references the linkbases and imports the type definition file.

This file includes the DATA Act project type definitions and xbrl concept elements.  The type definitions include element type restrictions of facets such as lengths, patterns, and enumerations.

2. daims-20160429_pre.xml

This is the presentation linkbase for the schema.  It covers packages A - F, each package is a separate link role.

3. daims-20160429_lab.xml

This is the label linkbase which provides standard, terse, documentation, instruction and rules labels for the concept elements in the schema.

4. daims-20160429_lab_enum.xml

This is the label linkbase which provides enumerations labels for the elements with restriction enumerations in the schema.  Also included are generic standard labels for non-concept elements in the schema (typed dimension member elements that aren't concept items).  This linkbase is separate from the _lab.xml label linkbase because it provides XBRL generic labels for each schema enumeration restrictions and non-concept elements.

5. daims-20160429_def.xml

This is the definition linkbase for the schema which defines dimensions and dimensional validation.  Data act dimensions are primarily code-enumerative typed dimensions, the code values of agency inputs have been preserved for compatibility with XBRL OIM CSV notation (instead of converting code values into XBRL Concept QNames).

6. daims-20160429_ref.xml

This is the reference linkbase for the taxonomy concepts references such as the RSS-IDD reference number.

6. daims-20160429_ref_metadata.xml

This is the reference linkbase for the taxonomy concepts metadata such as element level Required, Required Context and Rule codes.

8. versioning-report-20160429.xml

This is the XBRL standard versioning report, which is linked to the project change log file (http://x.y.z), and summarizes for XBRL tools the change log actions pertaining to XBRL elements and relationships.  (Version 1 versioning report will be generated, the current contents is a place-holder.)

XBRL Taxonomy Package Structure

The XBRL Taxonomy Package (which contains this README.txt file) is a zip file according to the XBRL specification at http://specifications.xbrl.org/work-product-index-taxonomy-packages-taxonomy-packages-1.0.html.

The taxonomy is specified by separate link roles (presentation groups) corresponding to DAIMS packages A, B, C, D1, D2, E and F.  Each XBRL link role uses the corresponding presentation group name:

Package	Link Role
Pkg A	0100 Appropriation Account Information
Pkg B	0200 TAS-ProgramActivity-ObjectClass Package
Pkg C	0300 TAS-ProgramActivity-ObjectClass-Award Package
Pkg D1	0400 Award Actions Information
Pkg D2	0500 Award Recipient Information
Pkg E	0600 Award Recipient Highly Compensated Officer Information
Pkg F	0700 Sub Award Information


XBRL Taxonomy Background

The taxonomy is developed using current best practice for XBRL, and stored in the XML syntax used at present by XBRL.  It can also be represented by an XBRL database (using the XBRL abstract model). 

The XBRL model for DAIMS is a standard authority-provided taxonomy, it does not anticipate per-filing extensions such as used by SEC and IFRS financial reporting. 

XBRL is processed using an XBRL processor (not an XML parser).  Open source and commercial products are available to process XBRL and load databases of XBRL-sourced data.

Sample XBRL instances (provided in an independent zip file) were developed by generating XBRL facts that meet the record structure of XBRL instances and are presently available in XBRL�s original XML syntax.  Consideration of Open Information Model style instances is proposed for a future sprint (in XBRL OIM JSON or CSV syntaxes). Each instance document contains a serialization of XBRL�s schema reference, contexts, and elements (for a discussion of current XML serialization and flat fact space, see https://www.corefiling.com/publications/documents/XMLflattened.pdf)

The schema and linkbase files follow the XBRL Taxonomy Architecture Guidance (http://www.xbrl.org/guidance/taxonomy-architecture/XBRLTaxonomyGuidanceDocument-v1.2.pdf), which results in well-modeled semantics that are interoperable between a large number of tools and agencies. XBRL serializes its model as an XML schema and linkbases, but is evolving to support multiple serialization and database standards (such as JSON, CSV, and SQL).  In particular, these metadata of the DAIMS project are modelled by XBRL as follows:

DAIMS	XBRL Metadata
Package	Link role
Element	Concept
Element order	Presentation linkbase order
" semantic label	Concept standard label, name (camel-cased tokenized name)
" Standard definition	Concept documentation label
" New/Modified definition	Concept supplemental documentation label
" Instructions	Concept instructions label
" Value required	Concept submission requirement label
" Abstract	Schema abstract attribute (true/false)
" Value required	Concept required reference part
" Validation rules code(s)	Concept validation rules reference part(s) (codes)
" Validation rules description	Concept validation rules label
" Required context	Concept required context reference part
" Enumeration	Schema-level enumeration restriction
" Enumeration labels	Generic standard labels on enumeration restriction elements
Presentation order	Presentation linkbase
Record structure	XBRL context containers (typed dimensions)
Version report	XBRL version report
Zip file of taxonomy	XBRL taxonomy package
Instance document	XBRL instance documents in XML, or OIM in CSV or JSON
